from pathlib import Path
import sys,zipfile,json
root=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(sys.argv[1]).resolve()/'scripts'))
from build_addon import build_addon
output=root.parent/'Moor-Mushroom-Launch-v1.0.0.zip'
source=(root/'moor_mushroom_launch.lua').read_bytes()
build_addon('mods/custom/moor_mushroom_launch',source,'62eb41fb-d8c6-432b-9c54-8096d2fb64b4',output,'Moor Mushroom Launch')
with zipfile.ZipFile(output) as z: files={n:z.read(n) for n in z.namelist()}
m=json.loads(files['manifest.json'])
d='v1.0.0 - Stronger Moor Mushroom launches, tested stagger/push 55/55. Configurable through settings.ini. Shared explosion profile. Miker and ChatGPT/Codex. Requires Bingus Shared Loader API 1.'
m['Description']=d;m['Options'][0]['Description']=d
files['manifest.json']=(json.dumps(m,indent=2)+'\n').encode()
files['Source/moor_mushroom_launch.lua']=source
files['Source/build.py']=Path(__file__).read_bytes()
for name in ('README.md','DESCRIPTION.txt'):
 files[name]=(root/name).read_bytes()
 files['Source/'+name]=files[name]
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in files.items():z.writestr(name,data)
print(output)
