-- HD2-Addon: mods/custom/moor_mushroom_launch
-- Moor Mushroom Launch v1.0.0. Miker and ChatGPT/Codex. Shared damage record 485.
-- Memory reader adapted from the user-supplied M6C addon / our Dagger experiment.
if rawget(_G, 'MoorMushroomLaunch') then return end
local ffi_ok, ffi = pcall(require, 'ffi')
assert(ffi_ok and ffi, 'LuaJIT FFI required')
local CHUNK = 262144
local MEM_COMMIT, MEM_PRIVATE = 0x1000, 0x20000
local PAGE_READONLY, PAGE_READWRITE = 0x02, 0x04
local function is_scannable_protection(p) return p==2 or p==4 or p==0x20 or p==0x40 end
local function build_api()
    -- Every mod shares one LuaJIT VM, so a cdef another mod already made wins. Declare
    -- one at a time and ignore redefinitions, take VirtualQuery's region as an opaque
    -- pointer so a differently-typed prior declaration still matches, and cast our own
    -- call to the typed signature.
    for _, declaration in ipairs({
        'void *GetCurrentProcess(void);',
        'int WriteProcessMemory(void *, void *, const void *, size_t, size_t *);',
        'int VirtualProtect(void *, size_t, uint32_t, uint32_t *);',
        'int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);',
        'size_t VirtualQuery(const void *address, void *region, size_t size);',
        'int CreateDirectoryA(const char *path, void *security);',
        'uint32_t GetLastError(void);',
        'void *memchr(const void *s, int c, size_t n);',
        'int memcmp(const void *a, const void *b, size_t n);',
    }) do
        pcall(ffi.cdef, declaration)
    end
    -- Uniquely named so it can never collide with another mod's region struct.
    pcall(ffi.cdef, [[typedef struct {
        void *base; void *allocation_base; uint32_t allocation_protection;
        uint16_t partition; uint16_t reserved; size_t size;
        uint32_t state; uint32_t protection; uint32_t type;
    } MoorMushroomLaunchRegion;]])

    local kernel = ffi.load('kernel32')
    local query = ffi.cast('size_t (*)(const void *, void *, size_t)', kernel.VirtualQuery)
    local process = kernel.GetCurrentProcess()
    local region = ffi.new('MoorMushroomLaunchRegion[1]')
    local region_size = ffi.sizeof(region[0])
    local counter = ffi.new('size_t[1]')

    -- One scratch buffer for the whole session. Allocating a fresh one per chunk and
    -- then calling ffi.string on it to search turns every megabyte scanned into two
    -- megabytes of garbage -- and this LuaJIT VM is shared with every other mod, so
    -- that collection pressure is not ours alone to pay. Measured on LuaJIT 2.1:
    -- 118 MB/s and 2048 KB of garbage per MB, against 7599 MB/s and 0.2 KB per MB for
    -- the C search below.
    local scratch = ffi.new('uint8_t[?]', CHUNK)

    -- Needles are registered before scanning starts and all of them are looked for in
    -- the same pass over each chunk.
    local needles, longest = {}, 0

    -- memchr/memcmp are byte-exact, so this finds exactly what string.find found --
    -- including a signature at an odd alignment. If another mod declared them with
    -- incompatible types, fall back to the Lua search rather than failing outright.
    local memchr, memcmp
    local c_search = pcall(function()
        memchr, memcmp = ffi.C.memchr, ffi.C.memcmp
        local probe = ffi.new('uint8_t[4]', {1, 2, 3, 4})
        assert(memchr(probe, 3, 4) ~= nil and memcmp(probe, probe, 4) == 0)
    end)

    local self = {}
    self.c_search = c_search

    function self.add_needle(bytes)
        local entry = {text = bytes, len = #bytes, head = bytes:byte(1),
                       data = ffi.new('uint8_t[?]', #bytes)}
        ffi.copy(entry.data, bytes, #bytes)
        needles[#needles + 1] = entry
        if entry.len > longest then longest = entry.len end
        return #needles
    end

    -- Chunks must overlap by at least this much, or a needle straddling the boundary
    -- between two reads is seen by neither.
    function self.longest_needle() return longest end

    -- Pointer arguments are always cast: passing a bare Lua number raises
    -- "cannot convert number to const void *" and kills the whole scan.
    function self.read(address, size)
        if size <= 0 then return nil end
        local buffer = ffi.new('uint8_t[?]', size)
        if kernel.ReadProcessMemory(process, ffi.cast('const void *', address),
                                    buffer, size, counter) == 0 then return nil end
        if tonumber(counter[0]) ~= size then return nil end
        return ffi.string(buffer, size)
    end

    function self.query(address)
        if query(ffi.cast('const void *', address), region, region_size) ~= region_size then
            return nil
        end
        local base = tonumber(ffi.cast('uintptr_t', region[0].base))
        local size = tonumber(region[0].size)
        if not base or not size or size <= 0 then return nil end
        return {base = base, size = size, state = region[0].state,
                protection = region[0].protection, kind = region[0].type,
                -- VirtualQuery's allocation base: the VirtualAlloc that owns this
                -- region. The loader lays the data tables out relative to it, which
                -- is what turns the locate below into a comparison, not a sweep.
                allocation_base = tonumber(ffi.cast('uintptr_t', region[0].allocation_base))}
    end

    -- Read one chunk into the scratch buffer and report every signature hit in it.
    -- Returns false if the chunk could not be read at all.
    function self.scan(address, size, found)
        if size <= 0 or size > CHUNK then return false end
        if kernel.ReadProcessMemory(process, ffi.cast('const void *', address),
                                    scratch, size, counter) == 0 then return false end
        if tonumber(counter[0]) ~= size then return false end
        if c_search then
            for index = 1, #needles do
                local entry = needles[index]
                local cursor, remaining = scratch, size
                while remaining >= entry.len do
                    local hit = memchr(cursor, entry.head, remaining - entry.len + 1)
                    if hit == nil then break end
                    hit = ffi.cast('uint8_t *', hit)
                    local step = tonumber(hit - cursor)
                    if memcmp(hit, entry.data, entry.len) == 0 then
                        found(address + (size - remaining) + step, index)
                    end
                    remaining = remaining - step - 1
                    cursor = hit + 1
                end
            end
        else
            local blob = ffi.string(scratch, size)
            for index = 1, #needles do
                local entry = needles[index]
                local position = 1
                while true do
                    local hit = blob:find(entry.text, position, true)
                    if not hit then break end
                    found(address + hit - 1, index)
                    position = hit + 1
                end
            end
        end
        return true
    end

    function self.address_of(text)
        local ok, value = pcall(function()
            return tonumber(ffi.cast('uintptr_t', ffi.cast('const char *', text)))
        end)
        if ok then return value end
        return nil
    end

    function self.mkdir(path)
        return kernel.CreateDirectoryA(path, nil) ~= 0 or kernel.GetLastError() == 183
    end

    local protect=ffi.cast('int (*)(void *,size_t,uint32_t,uint32_t *)',kernel.VirtualProtect)
    function self.write(address,bytes)
        if #bytes~=4 or address%4~=0 then return false end
        local info=self.query(address)
        if not info or info.state~=MEM_COMMIT or info.kind~=MEM_PRIVATE
            or (info.protection~=2 and info.protection~=4)
            or address<info.base or address+4>info.base+info.size then return false end
        local old=ffi.new('uint32_t[1]')
        local changed=info.protection==2
        if changed and protect(ffi.cast('void *',address),4,4,old)==0 then return false end
        local prior=tonumber(old[0])
        local ok,wrote=pcall(function()
            return kernel.WriteProcessMemory(process,ffi.cast('void *',address),bytes,4,counter)~=0
                and tonumber(counter[0])==4
        end)
        if changed then
            local restored=protect(ffi.cast('void *',address),4,prior,old)~=0
            if not restored then restored=protect(ffi.cast('void *',address),4,prior,old)~=0 end
            local check=self.query(address)
            if not restored or not check or check.protection~=prior then
                error('page protection could not be restored; restart game')
            end
        end
        return ok and wrote
    end
    return self
end


local function fromhex(text) return (text:gsub('..',function(x)return string.char(tonumber(x,16))end)) end
local SIGNATURE=fromhex('4c444c4401000000f02ca7e0')
local ORIGINAL=fromhex('e501000005000000050000000300000000000000000000000000000014000000190000000f000000000000002600000000004842000000000000000000000000000000000000000000000000')
local options={enabled=1,stagger=55,push=55}
local TARGET
local function parse_config(text)
 local out={enabled=1,stagger=55,push=55};local seen={}
 for line in text:gmatch('[^\r\n]+')do
  line=line:gsub('[#;].*$',''):match('^%s*(.-)%s*$')
  if line~='' then
   local k,v=line:match('^([%a_]+)%s*=%s*(%d+)%s*$')
   assert(k and out[k]~=nil,'unknown or malformed setting: '..line)
   assert(not seen[k],'duplicate setting: '..k);seen[k]=true
   out[k]=assert(tonumber(v))
  end
 end
 assert(out.enabled==0 or out.enabled==1,'enabled must be 0 or 1')
 assert(out.stagger>=0 and out.stagger<=1000,'stagger must be an integer 0..1000')
 assert(out.push>=0 and out.push<=1000,'push must be an integer 0..1000')
 return out
end
local function word(n)return string.char(n%256,math.floor(n/256)%256,math.floor(n/65536)%256,math.floor(n/16777216)%256)end
local function configure(out)
 options=out
 TARGET=ORIGINAL:sub(1,32)..word(out.stagger)..word(out.push)..ORIGINAL:sub(41)
end
configure(options)
local function u32(s,o)
 local a,b,c,d=s:byte(o+1,o+4);if not d then return nil end
 return a+b*256+c*65536+d*16777216
end
local function apply(memory,address)
 local head=memory.read(address,40)
 if not head or #head~=40 then return 'unreadable' end
 if head:sub(1,12)~=SIGNATURE then return 'header mismatch' end
 local count=u32(head,32);local size=u32(head,12)
 if not count or count<1 or count>10000 or size~=16+count*76 or u32(head,36)~=0 then return 'layout mismatch' end
 local rows=memory.read(address+40,count*76)
 if not rows or #rows~=count*76 then return 'unreadable rows' end
 local offset=nil
 for i=0,count-1 do
  if u32(rows,i*76)==485 then
   if offset then return 'duplicate id' end
   offset=i*76
  end
 end
 if not offset then return 'id not found' end
 local before=rows:sub(offset+1,offset+76)
 if before==TARGET then return 'already' end
 if before~=ORIGINAL then return 'record fingerprint mismatch' end
 local record=address+40+offset;local attempted={}
 local ok=pcall(function()
  for _,o in ipairs({32,36})do
   attempted[#attempted+1]=o
   assert(memory.write(record+o,TARGET:sub(o+1,o+4)),'write failed')
  end
  assert(memory.read(record,76)==TARGET,'readback mismatch')
 end)
 if ok then return 'patched' end
 local restored=true
 for i=#attempted,1,-1 do
  local o=attempted[i];local good,result=pcall(memory.write,record+o,before:sub(o+1,o+4))
  if not good or not result then restored=false end
 end
 local checked,back=pcall(memory.read,record,76)
 if not restored or not checked or back~=before then error('write failed; rollback not verified - restart game')end
 return 'write failed; original restored'
end
if ...=='mushroom_test' then return {apply=apply,parse_config=parse_config,configure=configure}end
local api=build_api()
local state={frame=0,cursor=0,bytes=0,patched=0,seen={},done=false}
_G.MoorMushroomLaunch=state
local base=assert(os.getenv('LOCALAPPDATA'),'LOCALAPPDATA missing')
for _,part in ipairs({'CowboyBingus','Helldivers2','MoorMushroomLaunch'}) do
    base=base..'/'..part;assert(api.mkdir(base),'cannot create log folder')
end
local function status(message)
    local f=assert(io.open(base..'/STATUS.txt','w'))
    f:write(message..'\nMatched table copies: '..state.patched..'\nBytes scanned: '..state.bytes..'\n')
    f:close()
end
local config_path=base..'/settings.ini'
local config_ok,parsed=pcall(function()
 local f=io.open(config_path,'r')
 if f then local text=f:read('*a');f:close();return parse_config(text)end
 local out=assert(io.open(config_path,'w'),'cannot create settings.ini')
 assert(out:write('; Moor Mushroom Launch v1.0.0 - restart after edits.\n'
  ..'; Shared profile: also affects another explosion consistent with Illuminate power nodes.\n'
  ..'; Captured stock: stagger 25, push 15. Tested defaults: 55/55.\n'
  ..'; Stagger influences hit reaction; push influences launch impulse. Distance is not linear or guaranteed.\n'
  ..'; Whole numbers 0..1000. Limits are not gameplay-tested ranges.\n'
  ..'enabled=1\nstagger=55\npush=55\n'));assert(out:close())
 return parse_config('')
end)
if not config_ok then status('CONFIGURATION ERROR - '..tostring(parsed));return end
if parsed.enabled==0 then status('DISABLED by settings.ini');return end
configure(parsed)
local summary='stagger '..options.stagger..'; push '..options.push..' (shared profile)'
local id=api.add_needle(SIGNATURE)
local current=nil
local function found(address)
    if state.seen[address] then return end
    state.seen[address]=true
    local result=apply(api,address)
    if result=='patched' or result=='already' then
        state.patched=state.patched+1
        print('[MoorMushroomLaunch] '..result..': '..summary)
        status('APPLIED - '..summary)
    end
end
local function tick()
    state.frame=state.frame+1
    if state.frame<120 then return end
    local deadline=os.clock()+0.0015
    while os.clock()<deadline do
        if not current then
            local info=api.query(state.cursor)
            if not info or state.cursor>=0x7FFFFFFF0000 then state.done=true;break end
            local next_address=info.base+info.size
            if next_address<=state.cursor then error('region scan did not advance') end
            state.cursor=next_address
            if info.state==MEM_COMMIT and info.kind==MEM_PRIVATE
                and (info.protection==2 or info.protection==4) then
                current={address=info.base,remaining=info.size}
            end
        else
            local n=math.min(CHUNK,current.remaining)
            -- Queue hits: do not change source pages while the scanner uses its buffer.
            local hits={}
            api.scan(current.address,n,function(address)hits[#hits+1]=address end)
            for _,address in ipairs(hits) do found(address) end
            state.bytes=state.bytes+n
            if n==current.remaining then current=nil else
                current.address=current.address+n-11;current.remaining=current.remaining-n+11
            end
        end
    end
    if state.done then
        status(state.patched>0 and ('DONE - '..summary)
            or 'NO MATCH - mushroom profile unchanged; send STATUS.txt')
    end
end
assert(type(update)=='function','game update callback unavailable')
local previous=update
local function pack(...)return {n=select('#',...),...}end
local function after(...)
    local r=pack(...)
    local ok,err=pcall(tick)
    if not ok then state.done=true;pcall(status,'FAILED - '..tostring(err)) end
    return unpack(r,1,r.n)
end
update=function(...)
    if state.done then return previous(...) end
    return after(previous(...))
end
status('WAITING - v1.0.0; '..summary)
